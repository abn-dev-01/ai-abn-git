# Lazy Dev Kit для Junie (аналог ponytail)

Набор файлов, повторяющий поведение плагина `ponytail` для JetBrains Junie:
lazy-dev ruleset + автоматически триггерящиеся skills + явные slash-команды.
Собран по официальной документации Junie (junie.jetbrains.com/docs) —
без сторонних плагинов и хуков, только встроенные механизмы Junie:
Guidelines, Agent Skills, Custom slash commands.

## Что внутри

```
.junie/
├── AGENTS.md                     ← always-on правила (аналог основного
│                                    ruleset'а ponytail), читается Junie
│                                    при КАЖДОМ промпте
├── skills/
│   ├── lazy-build/SKILL.md       ← триггерится при написании нового кода
│   ├── lazy-review/SKILL.md      ← триггерится при ревью diff'а
│   └── lazy-audit/SKILL.md       ← триггерится при аудите всего репо
└── commands/
    ├── lazy-review.md            ← явный вызов: /lazy-review branch=main
    ├── lazy-audit.md             ← явный вызов: /lazy-audit scope=batch-engine
    └── lazy-debt.md              ← явный вызов: /lazy-debt output=DEBT.md
```

## Установка

1. Скопируй папку `.junie/` в корень своего проекта (например,
   `batch-engine` или `Hyperion Provider Hub`).
2. Закоммить `.junie/` в git — тогда правила и команды будут общими для
   всей команды (так же, как рекомендует официальная документация Junie).
3. Перезапусти Junie CLI / плагин в IDE, чтобы он перечитал конфигурацию.

Если хочешь применить набор глобально ко всем своим проектам, а не только
к одному репозиторию — скопируй содержимое `.junie/skills/` в
`~/.junie/skills/`, `.junie/commands/` в `~/.junie/commands/`, а
`.junie/AGENTS.md` — в `~/.junie/AGENTS.md`.

## Проверка, что всё подхватилось

- Спроси Junie: "какие у тебя есть skills?" — должны появиться
  `lazy-build`, `lazy-review`, `lazy-audit`.
- Введи `/` в промпте — в списке команд должны появиться `/lazy-review`,
  `/lazy-audit`, `/lazy-debt`.
- Дай простую задачу на добавление кода и проверь, что Junie в ответе
  явно называет "ступень лестницы" — это признак того, что `AGENTS.md`
  и skill `lazy-build` реально применяются.

## Отличия от оригинального ponytail и на что обратить внимание

- Ponytail — мультиагентный плагин с нативными lifecycle-хуками для
  многих агентов (Claude Code, Codex, Cursor и др.). Этот набор сделан
  специально под Junie и использует только официально документированные
  механизмы Junie (Guidelines, Agent Skills, Custom slash commands) —
  никаких хуков не устанавливается, поэтому поведение полностью
  прозрачно и не выполняет код при каждом промпте, только читает
  markdown-файлы.
- Junie сама решает, когда триггерить skill, на основе `description` —
  если Junie не подхватывает `lazy-build` на конкретной задаче, попробуй
  явно попросить: "используй skill lazy-build для этой задачи".
- Кастомные slash-команды в Junie **требуют все объявленные `$аргументы`
  при каждом вызове** (в отличие от некоторых других агентов, где
  аргументы опциональны) — поэтому `/lazy-review`, `/lazy-audit` и
  `/lazy-debt` всегда вызываются с явным аргументом, как показано в
  примерах выше.
- Маркер технического долга — `// lazy-dev: ...` (а не `ponytail: ...`
  как в оригинале), чтобы не путать с реальным ponytail, если он тоже
  где-то установлен в этом же проекте.

## Источники (официальная документация Junie)

- Guidelines and memory: https://junie.jetbrains.com/docs/guidelines-and-memory.html
- Agent skills: https://junie.jetbrains.com/docs/agent-skills.html
- Custom slash commands: https://junie.jetbrains.com/docs/custom-slash-commands.html
